# Import stages for easier access
from .if_stage import IFStage
from .id_stage import IDStage
from .ex_stage import EXStage
from .mem_stage import MEMStage
from .wb_stage import WBStage